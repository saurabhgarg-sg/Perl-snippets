#!/usr/bin/perl

use strict;
use warnings;

## Script to generate dynmaic groups for sc02 of 873-sp8 testing
## For clarifications contact Saurabh Garg sgarg@novell.com

my $groups=1;
my $groupContext="ou=customers,o=organization";

open(LDIF,">sc02-dgs.ldif")||die "cannot create the LDIF file\n";

for($groups=1;$groups<=15;$groups++) {
print LDIF "dn: cn=DynamicGroup$groups,$groupContext\n";
print LDIF "dgIdentity: cn=admin,ou=administrators,o=organization\n";
print LDIF "memberQueryURL: ldap:///ou=engineering,o=organization??one?(novellTeamCode=edir-ST)\n";
print LDIF "memberQueryURL: ldap:///ou=human resources,o=organization??one?(novellTeamCode=edir-ST)\n";
print LDIF "memberQueryURL: ldap:///ou=finance,o=organization??one?(novellTeamCode=edir-ST)\n";
print LDIF "memberQueryURL: ldap:///ou=marketing,o=organization??one?(novellTeamCode=edir-ST)\n";
print LDIF "memberQueryURL: ldap:///ou=quality assurance,o=organization??one?(novellTeamCode=edir-ST)\n";
print LDIF "memberQueryURL: ldap:///ou=contractors,o=organization??one?(novellTeamCode=edir-ST)\n";
print LDIF "memberQueryURL: ldap:///ou=support,o=organization??one?(novellTeamCode=edir-ST)\n";
print LDIF "memberQueryURL: ldap:///ou=sales,o=organization??one?(novellTeamCode=edir-ST)\n";
print LDIF "objectClass: dynamicGroup\n";
print LDIF "objectClass: dynamicGroupAux\n\n";
}

my @langs = ("en","Ka","Ta","Hi","Sp","Ch","Ja","Po","Fr","It","Du","Te");

for($groups=16;$groups<=25;$groups++) {
print LDIF "dn: cn=DynamicGroup$groups,$groupContext\n";
print LDIF "dgIdentity: cn=admin,ou=administrators,o=organization\n";
print LDIF "memberQueryURL: ldap:///ou=engineering,o=organization??one?(preferedLanguage=$langs[$groups-16]*)\n";
print LDIF "memberQueryURL: ldap:///ou=human resources,o=organization??one?(preferedLanguage=$langs[$groups-16]*)\n";
print LDIF "memberQueryURL: ldap:///ou=finance,o=organization??one?(preferedLanguage=$langs[$groups-16]*)\n";
print LDIF "memberQueryURL: ldap:///ou=marketing,o=organization??one?(preferedLanguage=$langs[$groups-16]*)\n";
print LDIF "memberQueryURL: ldap:///ou=quality assurance,o=organization??one?(preferedLanguage=$langs[$groups-16]*)\n";
print LDIF "memberQueryURL: ldap:///ou=contractors,o=organization??one?(preferedLanguage=$langs[$groups-16]*)\n";
print LDIF "memberQueryURL: ldap:///ou=support,o=organization??one?(preferedLanguage=$langs[$groups-16]*)\n";
print LDIF "memberQueryURL: ldap:///ou=sales,o=organization??one?(preferedLanguage=$langs[$groups-16]*)\n";
print LDIF "objectClass: dynamicGroup\n";
print LDIF "objectClass: dynamicGroupAux\n\n";
}
