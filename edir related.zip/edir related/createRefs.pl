#!/usr/bin/perl

open(refLDIF,">references.ldif")||die  "cannot create references.ldif" ;

@OUs = ("manager","secretary","assistant","qa","director","president","vicepresident","admin","hr","helpdeskengineer");

foreach $ou (@OUs){
open(DNs,"refs")||die "cannot open refs file" ;
        while (defined ($line=<DNs>)){
                chomp $line ;
                print refLDIF "\ndn: ".$line.",ou=".$ou.",ou=references,o=organization\nchangetype: add\nobjectclass: top\nobjectClass: inetOrgPerson\nobjectClass: organizationalPerson\nobjectClass: Person\n";
                @names = split(/ /,$line,2);
                @morenames = split(/=/,$names[0],2);
                $names[0] = $morenames[1];
                print refLDIF "cn: $names[0]";
         if(length($names[1])<1){
        $names[1] = $names[0];
}
print refLDIF "\nsn: $names[1]\n";
                }
close(DNs);
}

close(refLDIF);