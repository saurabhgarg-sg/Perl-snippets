#!/usr/bin/perl

use strict;
use warnings;

## Script to generate dynmaic groups for sc02 of 873-sp8 testing
## For clarifications contact Saurabh Garg sgarg@novell.com

my $groups=1;
my $groupContext="o=organization";

open(LDIF,">sc02-dgs.ldif")||die "cannot create the LDIF file\n";
my @ous = qw/ nds md5 universal ssha simple /;

for($groups=1;$groups<=5;$groups++) {
print LDIF "dn: cn=DynamicGroup$groups,$groupContext\n";
print LDIF "dgIdentity: cn=admin,ou=administrators,o=organization\n";
print LDIF "memberQueryURL: ldap:///ou=$ous[$groups-1],ou=administrators,o=organization??sub?(objectClass=inetOrgPerson)\n";
print LDIF "objectClass: dynamicGroup\n";
print LDIF "objectClass: dynamicGroupAux\n\n";
}
