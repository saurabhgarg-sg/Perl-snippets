#!/usr/bin/perl

use strict;
use warnings;

# create the administrators containers first

open(LDIFFILE,"> sc01-tree.ldif")||die "cannot create the LDIF file";

my @admins = ("nds","md5","ssha","sha","simple","x509","mutual");

foreach my $admin (@admins){
        print LDIFFILE "\ndn: ou=$admin,ou=administrators,o=organization\nobjectclass: organizationalunit\n";
}

my $i=1;

for($i=1;$i<=7;$i++){
 print LDIFFILE "\ndn: ou=campus$i,o=organization\nobjectclass: organizationalunit\n";
        for(my $j=1;$j<=3;$j++){
                print LDIFFILE "\ndn: ou=building$j,ou=campus$i,o=organization\nobjectclass: organizationalunit\n";
                print LDIFFILE "\ndn: ou=user,ou=building$j,ou=campus$i,o=organization\nobjectclass: organizationalunit\n";
        }
}

close (LDIFFILE);
