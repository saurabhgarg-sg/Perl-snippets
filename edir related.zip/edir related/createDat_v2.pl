#!/usr/bin/perl

use strict;
use warnings;

if((scalar(@ARGV))!=2){
        print "\n usage: perl creaDat.pl <input file> <output file>\n\n" ;
}
else{
        
open(INPUT,$ARGV[0]) || die "cannot open input file $ARGV[0]" ;
open(OUTPUT,"> $ARGV[1]") || die "cannot open output file $ARGV[1]";
print OUTPUT "$ARGV[1]\n";

        while(defined (my $line=<INPUT>)){
                if($line=~m/^dn:/){
                        my @temp = split(/:/,$line,2);
                        $temp[1]=~ s/^\s// ;
                        print OUTPUT "$temp[1]";
                }
        }
print OUTPUT "\n";
close (INPUT);
close (OUTPUT);
}
