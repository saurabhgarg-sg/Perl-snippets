# keyword parameter
# simulates overloading concept
#	overload : more than one ways of calling fn
# simulation of default parameters

print divide(NUM, 20, DEN, 5), "\n";
print divide(DEN, 5, NUM, 20), "\n";
print divide(NUM, 20);

# @_ = ('NUM', 20, 'DEN', 5);

sub divide
{
	my %arg = @_;
	$arg{DEN} = 1 unless(exists($arg{DEN}));
	return $arg{NUM} / $arg{DEN};
}
