use strict;
$, = "\t"; $\ = "\n";
my @a = (10, 20, 30);
my @b = (40, 50);
my @c = (60, 70, 80);
my @d = ( @a, @b, @c );
print "size : ", scalar(@d); # 8
my @e = ( \ @a, \ @b, \ @c);
print "size : ", scalar(@e); # 3
print "val : ", $e[2]->[1]; # 70
# arrow bet closing and opening bracket of any kind can be dropped
print "val : ", $e[2][1]; # 70

disp(@e);
disp1(@e);

sub disp
{
	my ($i, $j);
	local $\ = undef;
	local $, = undef;
	for($i = 0; $i < @_ ;$i++)
	{
#		print "row : ", $i;
		for($j = 0; $j < @{$_[$i]} ;$j++)
		{
			print $_[$i]->[$j], "\t";
		}
		print "\n";
	}
}


sub disp1
{
	my ($p, $v);
	local $\ = undef;
	local $, = undef;
	foreach $p (@_)
	{
		foreach $v (@$p)
		{
			print $v, "\t";
		}	
		print "\n";
	}
}











