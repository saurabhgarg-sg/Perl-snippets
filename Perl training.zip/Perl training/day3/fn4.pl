package main;
# life and scope
# 1. global
#	can be accessed anywhere
#	can be changed anywhere
#	can also create  anywhere
# 2. my
#	automatic variable of 'C'
#	available in the block in which it is defined
#	static scope (compile time)

# 3. local
#	available in any fn called from there onwards
#	dynamic scope
#	localize the effect of change of global variable
#	replaces global variable temporarily
#	use local to change builtin variable of perl in 
#		local context

#	always use my otherwise

# local $/ = undef;


$\ = "\n"; $, = "\t";
$a = 10;
f();
print "main : a : $a b : $b c : $c";
# a : 1 b : 2 c : undef
$d = 111;
h();
print "d : $d"; # 111

sub f
{
	print "f : a : $a";
	$a = 11;
	my $b = 22; local $c = 33;
	g();
	print "f : a : $a b : $b c : $c";
	# a : 1 b : 22  c : 3 
	# :: scope resolution op
	print "global b : ", $main::b ;


} 

sub g
{
	print "g : a : $a b : $b c : $c";
	#	a : 11 b : undef c : 33
	$a = 1; $b = 2; $c = 3;
}


sub h
{
	local $d = 222;
	print "h : d : $d"; # 222
	print "h : d : ", $main::d ; # 222
}





