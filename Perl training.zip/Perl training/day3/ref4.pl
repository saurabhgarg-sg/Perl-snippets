# ref to sub
$, = "\t"; $\ = "\n";
sub f
{
	return "what";
}
$pf = \ f;  # fn gets called !
print "ref : ", ref($pf); # SCALAR !!!
print "val : ", $$pf; # what

$pf = \ &f; # & is a must
print "ref : ", ref($pf);  #CODE
# deref : &
print &$pf();
print $pf->();





