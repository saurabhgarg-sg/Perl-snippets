# ref to an array
$, = "\t"; $\ = "\n";
@y = (10, 20, 30, 40);
$py = \ @y;
print "ref : ", ref($py); # ARRAY
print "pointer : ", $py; # ARRAY(0x...)
# deref : @
print "array : ", @$py;
#print "array : ", $$py;  # error as $py is not a scalar ref
print "elem : ", $$py[2];
print "elem : ", $py->[2]; # commonly used
