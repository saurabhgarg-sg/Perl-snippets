# .pm => perl module
# module :
#	physical unit of reuse
#	not a keyword in the lang
#	generally has a package
# procedural / functional package
package util; # generally name of the package is same as that of the module

sub sqr
{
	return $_[0] * $_[0];
}

sub cube
{
	my $val = shift;
	return $val * $val * $val;
}

1; # module should return a true value
