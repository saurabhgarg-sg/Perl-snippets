# reference 
#	like pointer of 'C'
#	no pointer arithmetic
#	is a special scalar

$, = "\t"; $\ = "\n";

#	'C'  addr op : &	deref : *
#	Perl  addr op : \       deref : depends on context
#		scalar context : $

$x = 10;
$px = \ $x;
# check for scalar or reference : ref
print "ref x : ", ref($x);  # undef
print "ref px : ", ref($px); # SCALAR

print "px : ", $px; # SCALAR(0x.....)
print "value : ", $$px;
$$px = 20;
print "value : $x";





















