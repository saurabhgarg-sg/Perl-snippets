# arguments
#	1. no named parameters
#	2. no declaration of parameters
#	3. supports variable number of arguments
#	4. conceptually, copied into an array
#		called parameter array - name : @_
#	5. @_ : per fn call

f(10, 20, 30);

# walk thro the parameter array
sub f
{
	# for loop
	for($i = 0; $i < @_ ; ++$i)
	{
		print $_[$i], "\n";
	}

#	while(@_)
#	{
#		print shift(@_), "\n";
#	}
#	shift by default shifts the parameter array
	while(@_)
	{
		print shift, "\n";
	}
}

# simulate named parameter
print area(20, 10), "\n";

# @_ = (20, 10)
sub area
{
	$length = shift;
	$breadth = shift;
	return $length * $breadth;
}

# parameter passing : by reference
$a = 10; $b = 20;
what($a, $b);
print "a : $a b : $b \n";

sub what
{
#	$_[0] = 11;
#	$_[1] = 22;
# when we change an element of the parameter array,
#	corresponding arg will change
# when we change the parameter array, a new array is created,
#	references are removed
	@_ = (11, 22);
}





















