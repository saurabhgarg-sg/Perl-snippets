# client program
print "before use \n";
use utility; # module name and not package name
#	compile time mechanism
print "after use \n";
print util::sqr(10), "\n";
print util::cube(5), "\n";


