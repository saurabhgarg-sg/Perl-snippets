# structure : represent attributes of entity of real world
# perl : hash to represent a structure
# fields == keys
use strict;
my $r1 = { "L", 20, "B", 10 };
my $r2 = {"L", 30, "B", 5 };
my $r3 = {"L" => 40, "B" => 15 };
# =>  is called glorified comma
# same as comma
# used bet key and value

disp($r1);
disp($r2);
disp($r3);

sub disp
{
	my $self = shift;
	print $self->{"L"}, "\t", $self->{"B"}, "\n";
}
