# functions
#	development of program modularly
#	logical division 
#	separate client and server code

# 1. defn
# 2. invocation
# 3. return
# 4. parameter passing
# 5. life and scope
# 6. recursion
# 7. overload ?
# 8. default parameters ?

# fn defn
#	- there is no return type
#	- starts with keyword sub
#	- name has no prefix - bareword
#	- generally no parentheses following fn name
#	- no named parameters

# invoke the fn
#	can be called before or after defn
#	declaration not generally used
#	parentheses generally optional

#	1. with &
#	2. without &
#		called before defn => requires parentheses
#use strict;

print "before defn \n";
fn();
&fn();
&fn;
# function does not get called ! neither is it an error !
fn;  # 'fn';

sub fn
{
	print "in fn\n";
}

print "after defn \n";
fn();
&fn();
fn;
&fn;



