open FH, "dept.dat" or die $!;
$, = "\t"; $\ = "\n";
%dept = ();
while(<FH>)
{
	chomp;
	($dname, $ename) = split / /;
	#print $dname, $ename;
	# if deptname exists in the hash, append the name else initialize
	if(exists($dept{$dname}))
	{
		$dept{$dname} .= "|" . $ename;
	}
	else
	{
		$dept{$dname} = $ename;
	}	
}

foreach $dname (keys %dept)
{
	print $dname;
	foreach $ename (split /\|/, $dept{$dname})
	{
		print "\t", $ename;
	}
}
close FH;
