# package : avoid clash of global names
package A;
$x = 10;
package B;
$x = 20;
package main;
$x = 30;
print $x, "\t", $A::x, "\t", $B::x, "\n";

