# client for Rect.pm
use Rect;
$r = Rect->new(20, 10);
print ref($r), "\n";
print $r->area(), "\n";
# Rect::area($r)

# how to invoke new of Rect ?
#	a) Rect::new(20, 10)
#	b) Rect->new(20, 10)
#		Rect::new(Rect, 20, 10)
