# structure of structures
$, = "\t"; $\ = "\n";
$d = {
	DD => 26,
	MM => 12,
	YY => 2004
};

# %$d wrong
# \$d extra dereferencing
# $d

# structure of arrays
$e = {
	DETAIL => "Tsunami",
	DATE =>  $d,
	COUNTRIES => ["India", "Srilanka"] 
};

print "month : ", $e->{DATE}->{MM};
print "month : ", $e->{DATE}{MM};
# add a field
$e->{DATE}->{DAY} = "Sun";
print %$d;

print "country : ", $e->{COUNTRIES}->[0];
print "country : ", $e->{COUNTRIES}[0];



unshift( @{$e->{COUNTRIES}} , "Indonesia");
print "Countries : ", @{$e->{COUNTRIES}};











