# recursion
#	soln to a problem in terms of problem itself
#		but of a smaller size
#	require soln for simple case(s) - escape hatch

# a to the power m
print power(5, 3), "\n";

sub power
{
	my $a = shift;
	my $m = shift;
	if ($m == 0)
	{
		return 1;
	}
	else
	{
		return $a * power($a, $m - 1);
#					$m--  => infinite recursion
#					--$m => possible; bad 
	}
}





f(10, 20, 30);

sub g
{
	local $, = "\t";
	print "parameters : ", @_, "\n";
}

sub f
{
	g;  # g();  # no arg passed
	&g; # g(@_); # current parameter array is passed as arg
}











