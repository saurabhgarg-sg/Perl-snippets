print "hello \n";
fork();
print "world \n";

