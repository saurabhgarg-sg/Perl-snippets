
#print f(10, 20);
# trying output 10 and 20 to a file whose handle is f
print f (10, 20) or die($!);
sub f 
{
	return $_[0] + $_[1];
}

#print f(10, 20);
#print f (10, 20);


