# return value
#	list context
#	default :
#		returns the value of the last expression
#		in the order of execution
#	explicit :
#		return <Expr>
#		- more readable
#		- multiple returns

sub f
{
	print "in f\n";
}
# use function as an arg to print

print f();  # in f   1

sub g
{
	print "in f\n";
	1729;
}

print g(), "\n"; # 1729
sub h
{
	print "in f\n";
	1729;
	"Novell";

}
print h(), "\n"; # Novell

sub ff
{
	print "in f\n";
	1729;
	"Novell";
	("digital", "compaq", "hp");

}
print ff(), "\n"; # "digital", "compaq", "hp"

sub fact
{
	$n = 4;
	$p = 1;
	while($n)
	{
		$p *= $n --;
	}
#	$p;
	return $p;
}

print fact(), "\n";


$res = gg();
print "res : $res \n";
@res = gg();
print "res : @res \n";
# can we make out in which context the fn is being used ?
# wantarray : undef in scalar context; 1 in list context
sub gg
{
#	print "wantarray : ", wantarray(), "\n";
	if (wantarray())
	{
		return (11, 22, 33);
	}
	else
	{
		return 3;
	}
}








































