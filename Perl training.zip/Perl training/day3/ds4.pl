# array of structures
$, = "\t"; $\ = "\n";
$s0 = { Name => Rahul, Score => 8000 };
$s1 = { Name => Kaif, Score => 1000 };
$s2 = { Name => Sachin, Score => 11000 };
$s3 = { Name => Sunil, Score => 10000 };

@a = ( $s0, $s1, $s2, $s3);
# sort the array based on Score

@b = sort @a;
foreach ( @a) 
{
	print $_->{Name}, $_->{Score};
}

@b = sort {mycmp($a, $b) } @a;
foreach ( @b) 
{
	print $_->{Name}, $_->{Score};
}

sub mycmp
{
	my $l = shift; my $r = shift;
	return $r->{Score} <=> $l->{Score};
}












