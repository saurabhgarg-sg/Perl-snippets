@a = (11, 22, 33, 44);

# 1.
@b = @a;
# 2.
($x) = (11, 22, 33, 44);
# 3.
$x = (11, 22, 33, 44);
# 4
$x = @a;
# 5.
@b = 111;
# 6.
($x) = ($a, $b) = (11, 22, 33, 44);
# 7.
$x = ($a, $b) = (11, 22, 33, 44);
# 8.
# dynamic allocation
# rhs : not an array; ref to an anonymous array
$x = [ 10, 20, 30, 40 ];
$y = $x;
$x = "ant";
$y = "bat";
# array without access : garbage
# no memory leak; has a garbage collector
# garbage collection based on ref counting
# deterministic

# 9.
@x = [ 10, 20, 30, 40 ]; # might be wrong
print "size : ", scalar(@x), "\n";  # 1


# 10.
# rhs : ref to anonymous hash
$x = { 10, 20, 30, 40 };

# 11.
%x = { 10, 20, 30, 40 };# definitely wrong

# %x = 111;  # %x = (111)

# 12. ref to anonymous function
$x =  sub { print "hello \n" ; };



































