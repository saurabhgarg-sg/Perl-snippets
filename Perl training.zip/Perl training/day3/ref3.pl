# ref to hash
$, = "\t"; $\ = "\n";
%z = (10, 20, 30, 40);
$pz =  \ %z;
print "ref : ", ref($pz);  #HASH
# deref : %
print "Hash : ", %$pz ;
print "value : ", $$pz{30};
print "value : ", $pz->{30};  # more common


