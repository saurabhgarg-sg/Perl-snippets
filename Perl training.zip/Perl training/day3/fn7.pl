#
# function pointer stored in  a global structure
# initialized during compilation process
# fn names can not be overloaded
#	cannot modify the names by name mangling as there are 
#	no explicit parameters
# At the end of compilation, we can have only one fn called f
sub f
{
	print "one\n";
}

f();

sub f
{
	print "two\n";
}

f();
