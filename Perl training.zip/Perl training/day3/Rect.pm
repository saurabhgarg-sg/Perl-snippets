package Rect;
sub new
{
	my $class = shift;
	my $self = {
		L => shift,
		B => shift
	};
	# associate package name with the reference
	bless $self, $class; # ref becomes an object
	return $self;
}
# @_ = (ref to a hash)
sub area
{
	my $self = shift;
	return $self->{L} * $self->{B};
}
1;

