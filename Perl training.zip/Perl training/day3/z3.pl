# creates zombie
# avoid zombie, use explicit ignore in handling the signal
$SIG{CHLD} = "IGNORE";

print "before fork $$";
# returns true in the parent and false in the child
if( $pid = fork() )
{
	print "parent : $$\n";
	sleep 1000;
}
else
{
	print "child : $$\n";
}

