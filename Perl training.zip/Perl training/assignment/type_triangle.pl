  #!/usr/bin/perl

  use strict;
  use warnings;

  #============= main =====================#
  $, = "\t";

  print "Enter the three sides of the triangle:\n";

  my $a = <STDIN>;
  my $b = <STDIN>;
  my $c = <STDIN>;

  if(($a == $b)&&($a == $c))
  {
   print "It is a equilateral triangle";
  }
  elsif(($a==$b)||($a==$c)||($b==$c))
  {
   print "It is a isoceles triangle";
  }
  else{
  	print "It is a scalene triangle";
  }
  #============= main ends =====================#