  #!/usr/bin/perl

  use strict;
  use warnings;

  #============= main =====================#

             my $input=<STDIN>;
             chomp $input;
             my $counter;
             my $avg;
             my $sum;

             while ($input ne "no") {
             $counter += 1;
             $sum += $input ;
             print "\nsum = $sum";

             $avg = $sum/$counter;
             print "\nAverage: $avg";

             $input=<STDIN>;
             chomp $input;
             }
  print "\n\nNo hence exiting";
  #============= main ends =====================#
