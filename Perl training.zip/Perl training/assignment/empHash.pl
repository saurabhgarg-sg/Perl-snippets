#!/usr/bin/perl

use strict;
use warnings;

$,="\t";$\="\n";
my $debug=0;

my %emp=(100,"Hema",200,"Ritu",300,"Rekha",400,"Ritu");

foreach my $id (sort(keys(%emp))){
	print $id."\t".$emp{$id};
}

$"="\t";

my @keys = keys(%emp);
$debug && print "@keys";

my $i=0;
my $j;

for($i=0;$i<@keys;$i++){
	$debug && print "keys thru i is $keys[$i]";
		for($j=$i+1;$j<@keys;$j++){
		$debug && print "j is $j, keys thru j is $keys[$j]";
		$debug && print "value for i is $emp{$keys[$i]}, j is $emp{$keys[$j]}";
			if(($emp{$keys[$i]} cmp $emp{$keys[$j]})==0){
				print "duplicate found for $emp{$keys[$j]}, emp ids are $keys[$i] & $keys[$j]";
		}
   }
}


