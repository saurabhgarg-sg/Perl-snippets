#!/usr/bin/perl

#program to calculate the area of a triangle when 3 sides are given

use warnings;
use strict;

print "starting the execution";
#main
my $a = <STDIN>;
my $b = <STDIN>;
my $c = <STDIN>;

my $s = ($a + $b +$c)/2;
my $area = ($s*($s-$a)*($s-$b)*($s-$c))/2;

print $area ;