    #!/usr/bin/perl

    use strict;
    use warnings;

    #============= main =====================#

    print "Enter file name:";
    my $filename = <STDIN>;
    chomp $filename;

  if (-e $filename) {
                   print "\nfile exists now deleting it";
                   unlink ($filename);
                   } else {
                    print "file does not exist";
                    }

    #============= main ends =====================#