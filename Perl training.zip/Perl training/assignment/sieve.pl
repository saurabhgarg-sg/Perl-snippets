#!/usr/bin/perl

# Using Sieve theorem to find primes

use warnings;
use strict;

#====================== main ==================================#
my $debug=0;

print "\nEnter the number: ";
my $max = <STDIN>;
chomp $max;

my @all = (2..$max);
$"=", ";$\="\n";
$debug && print "@all";

my $divisor=2;

while($divisor < $max){

$debug && print "divisor is $divisor";

my $temp;
my $index;

for($index = 0;$index < @all ; $index++){

$debug && print "index is $index, value is $all[$index]" ;

if(($all[$index] != 0)&&
	(($all[$index]%$divisor)==0)&&
		($all[$index]!=$divisor)){
			$all[$index]=0;
		}
	}

$divisor++;
}
$\="\t";
foreach my $temp (@all){
	
$debug && print "temp is $temp" ;
	if($temp != 0){
		print $temp;
	}
}
print "\n";
#======================  ==================================#


