#!/usr/bin/perl
use strict;
use warnings;

# Program to remove all teh tags from HTML file
my $debug=0;

open(FILE,"/tmp/htm1.htm") || die "Cannot open HTML File, $!";

undef $/; my $BigStr = <FILE> || die "file too big";

$debug && print $BigStr;
$BigStr =~ s/\n/NLnlNL/g;
$BigStr =~ s!\<
		(\!\|\/)?
		.*?
		(\/)?\>!!gix ;
#remove & prefixed special tags now
$BigStr =~ s/\&nbsp\;/ /g;
$BigStr =~ s/\&quot\;/\"/g;
$BigStr =~ s/\&lt\;/\</g;
$BigStr =~ s/\&gt\;/\>/g;

$BigStr =~ s/NLnlNL/\n/g;
print "\n\nAfter processing: \n\n". $BigStr;
