# read from a file
open F, "x.dat" or die("x.dat : $!");
while( $line =	<F> )
{
	print $line;
}
close F;
