# read n numbers and populate an array
# the number should between 0 and 100
print "enter number of elements : ";
chomp($n = <STDIN>);
foreach $i (1 .. $n)
{
	$x = <STDIN>; chomp $x;
	redo if($x < 0 or $x > 100);
	$a[$i]= $x;
}
$, = "\t";
print @a, "\n";

# last : come out of the loop
# next : starts the next iteration
# redo : repeats the iteration


