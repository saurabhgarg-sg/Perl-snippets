# not a good program to write !
($x, $y) = (<STDIN>, <STDIN>);
print "x: $x\n";
print "y: $y\n";

