# arrange files in order of size
$, = "\t"; $\ = "\n";
@all = `ls -l`;
shift @all;
#print @all;
chomp @all;
foreach $line (@all)
{
	($size, $name) = (split / +/, $line)[4, 8];
#	print $name, $size;
	push(@tosort, join(":", $size, $name));
}
#print @tosort;
@sorted = sort {$b <=> $a } @tosort;
foreach $pair (@sorted)
{
	($size, $name) = split(/:/, $pair);
	print $name, $size;
}

