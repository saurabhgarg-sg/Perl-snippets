# usage : perl mycat3.pl <list of filenames>
# diamond operator
#	processes the array @ARGV
#	open the file for reading
#	display the file
#	close the file
while(<>)
{
	print;
}
