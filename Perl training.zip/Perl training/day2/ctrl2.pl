# test whether a number is prime
print "enter a number : ";
chomp($n = <STDIN>);
# divide by numbers from 2 to $n - 1
#
$i = 2;
while($i < $n )
{
# only one stmt in a control structure
#	we write stmt then the control part of it
	last if($n % $i == 0) ;
	$i++;
}

if($i == $n)
{
	print "$n is prime\n";
}
else
{
	print "$n is not a prime\n";
}

# next
# last
