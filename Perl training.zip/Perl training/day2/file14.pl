# pipe open
# read the output of a command on a different file handle
#	other than STDIN
# send input to a command on a file handle other than STDOUT 
open F, "ls|" or die $!;
open G, "|wc -l" or die $!;
while($line = <F>)
{
	print G $line;
}
close F;
close G;


