$, = "\t"; $\ = "\n";
# arrange files in decreasing order of size
opendir DH, "." or die $!;
while($name = readdir DH)
{
	$size = -s $name;
#	print $name, $size;
	$fileinfo{$name} = $size;
}
closedir DH;
# sort the keys based on the value
foreach $k (sort{ $fileinfo{$b} <=> $fileinfo{$a} }(keys(%fileinfo)))
{
	printf "%-10s %5d\n",  $k, $fileinfo{$k};
}

# sort strings based on length ???
