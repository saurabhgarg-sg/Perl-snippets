# test whether a number is prime
print "enter a number : ";
chomp($n = <STDIN>);
# divide by numbers from 2 to $n - 1
#
$i = 2;
while($i < $n )
{
	if($n % $i == 0)
	{
		# not prime
		last;   # break of 'c'
	}
	$i++;
}

if($i == $n)
{
	print "$n is prime\n";
}
else
{
	print "$n is not a prime\n";
}

# next
# last
