# environment variable
#	shell cmd : $ env
# perl : %ENV
$, = "\t"; $\ = "\n";
#print %ENV;
print "path : ", $ENV{PATH};
#`./a1`;
$ENV{PATH} .= ":."; 
system("a1");
print "status : ", $? ;

# in CGI
#	method : get / post
#	querystring



