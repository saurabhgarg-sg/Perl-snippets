# pipe open
# read the output of a command on a different file handle
#	other than STDIN
open F, "ls|" or die $!;
while($line = <F>)
{
	print $line;
}
close F;


