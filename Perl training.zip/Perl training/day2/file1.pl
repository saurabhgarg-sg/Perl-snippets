# files
#	a) physical name
#		according to OS
#		string
#	b) logical name
#		according to lang
#		identifier (bare word)
#		file handle
#	c) mode
#		read, write, append, ...
#	use strict;
# connect these => open
# default mode is read mode
# open filehandle, mode_with_filename
#open FH, "junk" or die($!);
#open FH, "junk" or warn($!);
open FH, "junk" or print($!);
# print :output to stdout; no info about line number or filename
# warn :output to stderr;  info about line number and filename

print "after open\n";

# error handling related to files should be taken care by the programmer
# die :
#	aborts the program
#	gives line number and filename

# warn :
#	gives a message ; does not abort the program
# $! :holds error message






