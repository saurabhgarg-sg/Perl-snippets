# usage : perl -n mycat5.pl <list of filenames>
# -p : introduces diamond loop and print within it
