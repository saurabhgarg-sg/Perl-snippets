#! /usr/bin/perl
# execution of cmd in shell
# 1. alias
# 2. user defined functions
# 3. shell builtins (internal commands)
# 4. external command (should be a file)
#	a) locate the file
#		if there is a slash
#			PATH is not used
#		else
#			PATH is used
#	b) execute it
#		should have execute permissions
#		i) binary file
#			creates a new shell - which is
#			replaced by loading the binary file
#		ii) text file
#			require a binary
#			inspect the first line
#			#! <path of a binary>
#			if present
#				start the binary
#				make the file input to it
#			else
#				execute it as a shell program\
#				sh or login shell 




print "hello world\n";

