print foreach (1 .. 10);
# print $_  foreach $_ (1 .. 10);

