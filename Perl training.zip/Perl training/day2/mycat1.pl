# usage : perl mycat1.pl <list of filenames>
foreach $argv (@ARGV)
{
#	open F, $argv or warn "$argv $!";# not ok; no read or closing allowed

	if(! open F, $argv )
	{
		warn "$argv $!";
		next;# same as continue of 'c'
	}
	while($line = <F>)
	{
		print $line;
	}
	close F;
}
