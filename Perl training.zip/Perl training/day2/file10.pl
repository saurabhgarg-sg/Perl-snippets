# open the file in write mode
#	>  write
#	default read
#	< read
#	>> append
#	overwrites the file
#	+<	r+ in 'C'
#	+> 	w+ in 'C'
open F, "+<a.dat" or die $!;
print F "fat";
close F;
