# sum of digits of a number
print "enter a number : ";
chomp($n = <STDIN>);
$, = "\t"; $\ = "\n";
#print split(//, $n);
#print join("+", split(//, $n));
print eval(join("+", split(//, $n)));

# eval <expr>
#	evaluates the expression in the current context
#eval '$a = 10';
#print $a;

