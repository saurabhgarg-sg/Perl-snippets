# usage : perl -p -i.old change.pl a.xml b.txt
s/ant/elephant/;

