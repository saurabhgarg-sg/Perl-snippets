# open the file in write mode
#	>  write
#	default read
#	< read
#	>> append
#	overwrites the file
#	+<	r+ in 'C'
#	+> 	w+ in 'C'
#	file becomes empty ; we can write into and read from the file
open F, "+>b.dat" or die $!;
print F "fat";
close F;
