# sum of digits of a number
print "enter a number : ";
chomp($n = <STDIN>);
$s = 0;
$i = 0;
while($n)
{
	print "in loop\n";
	$s += $n % 10;
#	$n /= 10;  # stores the fractional result
	$n = int($n / 10);
	$i++;
}
print "sum : $s\n";
print "number of iterations : $i \n";

