# find total for each batsman
open F, "score.dat" or die $!;
while(<F>)
{
	chomp ; # chomp $_
	($name, $runs) = split / /; # split / /, $_
	$total{$name} += $runs;
}
close F;
foreach $name (keys(%total))
{
	print $name, "\t", $total{$name}, "\n";
}
#	$total{$name} += $runs;
#	$total{$name} = $total{$name} + $runs

#	name sachin	rahul  	sachin
#	runs 50		60	150

#	%total
#		sachin  50  200
#		rahul	60

#sachin 50
#rahul 60
#sachin 150
#rahul 70
#sourav 90
#sourav 80





