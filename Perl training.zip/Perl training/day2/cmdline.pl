# command line arguments
# $0 : command name
# @ARGV : arguments
# no variable to hold the count
# @ARGV does not hold the command name

# 'C'    int main(int argc, char ** argv) ...
# argv[0]  is a pointer to the command


print "command name : ", $0, "\n";
print "arguments : \n";
foreach $argv (@ARGV)
{
	print $argv, "\n";
}
