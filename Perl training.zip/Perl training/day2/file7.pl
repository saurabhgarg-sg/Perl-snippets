# read from a file
# $/ input record sep
$/ = ",";
open F, "y.dat" or die("x.dat : $!");
$line =	<F>; # reads until and inclusive of input record sep
chomp $line;
print $line;
close F;
