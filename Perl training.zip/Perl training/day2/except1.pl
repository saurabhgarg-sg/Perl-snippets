# mechanism to care of unusual cases; avoid aborting the program
#	eval
#		eval <expr>
#		eval <block> ; exception handling
#	on an exception in the block,
#		block is exited

$a = 0;
$b = 10;
eval
{
	print "before division\n";
	print $b / $a, "\n";
	print "After division \n";
} ;
# $@ will have the error message if any
#print $@, "\n";
print " \$! : $! \n";
if($@)
{
	print "error encountered \n";
	print $@;
}
print "thats all \n";

