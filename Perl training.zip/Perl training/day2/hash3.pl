$, = "\n";
open f, "key.dat" or die $!;
%pair = <f>;
chomp %pair;
print %pair;
close f;
