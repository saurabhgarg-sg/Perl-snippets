# use hash to set signal handlers
$\ = "\n";
#foreach (sort keys %SIG)
#{
#	print;
#}
#exit 0;
$SIG{INT} = sub { print "signal recd \n"; exit(1); };

while(1)
{
	print "hello\n";
}
