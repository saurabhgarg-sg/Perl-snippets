# open the file in write mode
#	>  write
#	default read
#	< read
#	>> append
#	overwrites the file
#	+<	r+ in 'C'
#	+> 	w+ in 'C'
open F, "+<a.dat" or die $!;
# move back and forth :
#	seek filehandle, offset in bytes, whence
#		whence : direction of measurement of offset
#		0   beginning
#		1   current posn
#		2   end
seek F, 3, 0;
print F "fat";
close F;
