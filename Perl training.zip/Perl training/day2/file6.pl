# read from a file
# local $/ = undef;
$/ = undef;
open F, "x.dat" or die("x.dat : $!");
$line =	<F>; # reads the whole file into a single scalar
#	variable : slurping 
print $line;
close F;
