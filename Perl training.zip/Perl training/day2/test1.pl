$, = "\t";
@a = (1, 2, 3, 4);
print @a, "\n";
# $"  used in this display
# $" by default : " "
$" = "|";
print "@a \n";

