# read from a file
open F, "x.dat" or die("x.dat : $!");
$line =	<F>;
print $line;
close F;
