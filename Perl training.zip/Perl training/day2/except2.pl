# open a file
# die will not abort the program
# output of die goes to $@
eval 
{
	open F, "junk" or die("junk : $!");
	$x = <F>;
	print "line 1 $x \n";
};
if($@)
{
	print "error in file handling \n";
	print $@;
}
