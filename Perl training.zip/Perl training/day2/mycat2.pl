# usage : perl mycat2.pl <list of filenames>
foreach $argv (@ARGV)
{
#	open F, $argv or warn "$argv $!";# not ok; no read or closing allowed

	unless( open F, $argv )
	{
		warn "$argv $!";
		next;# same as continue of 'c'
	}
	while(<F>) # $_ = <F>
	{
		print ; # print $_
	}
	close F;
}
# unless :
#	selection structure
#	execute when cond is false
