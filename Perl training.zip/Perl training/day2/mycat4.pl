# usage : perl -n mycat4.pl <list of filenames>
# -n : introduces diamond loop
	print;
