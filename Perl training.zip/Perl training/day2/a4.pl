# array
@a = (10, 20, 30, 40);
#$x = @a;  # 4
#($x) = @a; # 10
# removing the first element
($x, @a) = @a;  # ($x, @a)= (10, 20, 30, 40)
print "x : $x\n";
print "a : @a \n";

@a = (10, 20, 30, 40);
(@a, $x) = @a; # $x becomes undef !

# shift removes the first element
@a = (10, 20, 30, 40);
$x = shift @a;
print "x : $x\n";
print "a : @a \n";

# add element in the beginning
@a = (10, 20, 30, 40);
$x = 50;
unshift @a, $x;
print "a : @a \n";


# remove the element at the end
@a = (10, 20, 30, 40);
$x = pop @a;
print "x : $x\n";
print "a : @a \n";

# add the element at the end
@a = (10, 20, 30, 40);
$x = 60;
push @a, $x;
print "a : @a \n";


$,  ="\t"; $\ = "\n";
@x = (15, 25, 2, 5, 3);
@y = reverse @x;
print @x;
print @y, "\n";

@y = sort(@x); # based on collating sequence
# @y = sort {$a cmp $b}(@x);
print @x;
print @y, "\n";

@y = sort{$a <=> $b}(@x); 
print @x;
print @y, "\n";

@y = sort{$b <=> $a}(@x); 
print @x;
print @y, "\n";
































