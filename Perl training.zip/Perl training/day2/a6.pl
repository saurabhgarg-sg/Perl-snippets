# arrange files in order of size
$, = "\t"; $\ = "\n";
# DH : used defined name; handle to the directory
opendir DH, ".";
while($name = readdir(DH))
{
	if( -f $name)
	{
		$size = (stat $name)[7];
		push(@tosort, join(":", $size, $name));
	}
}
closedir DH;
@sorted = sort {$b <=> $a } @tosort;
foreach $pair (@sorted)
{
	($size, $name) = split(/:/, $pair);
	print $name, $size;
}

# check
print (-s "a1.c");  # can also be used to get the size

