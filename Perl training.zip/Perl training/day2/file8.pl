# open the file in write mode
#	>  write
#	default read
#	< read
#	>> append
open G, ">z.dat" or die $!;
open F, "<x.dat" or die $!;
while($line = <F>)
{
	print G $line;
#	no comma between the file handle and the remaining args
}
close F;
close G;
