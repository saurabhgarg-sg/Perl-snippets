# hash
#	- key value pairs
#	- array indexed by string
#	- keys are unique
#	- key, value : scalars
#	- name starts with %
$, = "\t"; $\ = "\n";
%a = ("apple", "fruit", "bat", "cricket", "cat", "mammal");
print %a; # order of output no deterministic

# Art of Programming
# fundamental algo
# sorting and searching : Knuth
# seminumeric algo
@a = (11, 22, 33);
print "value : ", $a{"cat"};
print "value : ", $a["cat"]; # 0th element of array @a

# replace a value fora given key
$a{"cat"} = "cmd of unix";
print %a;

# adds a key value pair
$a{"dove"} = "bird";
print %a;

# remove key value pair
delete $a{"dove"};
print %a;
# function keys can  make out internally in which context
#	it is used - wantarray()
@k = keys(%a);
$k = keys(%a);
print "array k : ", @k; # all keys; order not defined
print "scalar k: ", $k; # number of keys
print values(%a);


foreach $k (sort keys %a)
{
	print "$k -> ", $a{$k};
}
print;
# use of list assignment in scalar context
while( ($k, $v) = each(%a) )
{
	print "$k -> $v";
}

%b = (1, (2, 3), 4, (5, 6)); # (1, 2, 3, 4, 5, 6);
print "val : ", $b{1}; # 2
@x = (2, 3); @y = (5, 6);
%c = (1, @x, 4, @y);
print "val : ", $c{1}; # 2

%d = (1, 2, 3, 4, 5);
# check for the key	: exists
# check value for a key : defined
print "exist : ", exists($d{3}); # 1
print "exist : ", exists($d{4}); # undef
print "exist : ", exists($d{5}); # 1
print "value : ", defined($d{4}); # undef
print "value : ", defined($d{3}); # 1 
print "value : ", defined($d{5}); # undef 























