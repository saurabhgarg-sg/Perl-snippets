# read from a file
open F, "x.dat" or die("x.dat : $!");
@line =	<F> or die ("file too big"); # <> in the list context
print @line;
close F;
