$_ = "blue bird";
/blue|black bird/;   # either blue or black bird
print $&, "\n";  # blue

$_ = "blue bird";
/(blue|black) bird/;   # either blue bird or black bird
print $&, "\n";  # blue bird

