package Ex2;
use Exporter;
@ISA = (Exporter); # inheritance
($a, $b, $c, $d, $e, $f, $g, $h) = (1 .. 8);
@EXPORT = ( '$a', '$b', '$c');
@EXPORT_OK = qw($d $e $f);
%EXPORT_TAGS = (
	SOME => [ qw($a $e) ],
	MORE => [ qw($b $c $d) ]
);
1;

