package Event;
use Date;
sub new
{
	my $class = shift;
	my $self = {
		DATE => Date->new(shift, shift, shift),
		DETAIL => shift
	};
	bless $self, $class;
	return $self;
}

sub disp
{
	my $self = shift;
	$self->{DATE}->disp();
	print "Detail : ", $self->{DETAIL}, "\n";
}
1;

