$, = "\t"; $\ = "\n";
@a = qw($a $b $c); # qw : quote word
print @a;
$a = "what";
$x = qq(this is a test $a);  # double quotes
print $x;
$x = q(this is a test $a);  # single quotes
print $x;
