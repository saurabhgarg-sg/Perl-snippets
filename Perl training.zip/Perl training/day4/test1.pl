print "hello \n";
$a = 10;
f();

sub f
{
	my $b = 20;
	print $b, "\n";
	$a++;
	print $a, "\n";
	g();
}

sub g
{
	$n = 4;
	while($n--)
	{
		print $n, "\n";
	}	

}

