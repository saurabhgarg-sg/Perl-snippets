use Complex;
$c1 = Complex->new(3, 4);
$c1->disp();
$c2 = new Complex(5, 6);
$c2->disp();
$c3 = $c1->add($c2);
# Complex::add($c1, $c2)
$c3->disp();
$c3 = $c1 + $c2;
$c3->disp();

