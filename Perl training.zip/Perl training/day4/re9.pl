# anchors : 0 witdh pattern
# rama
#	match
#	"rama"
#	"rama krishna"
#	"govinda rama"
#	"krishna rama govind"

# 	do not match
#	"ramakrishna"
#	"balarama"
#	"balaraman"

# /\srama\s/  matches 6 char

# boundary
# /\brama\b/	           



#	match  "ramakrishna"   /\brama\B/
#	match  "balarama"      /\Brama\b/
#	match "balaraman"      /\Brama\B/









