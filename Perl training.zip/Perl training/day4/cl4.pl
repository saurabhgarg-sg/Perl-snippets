# change value of @INC at compile time
# 1. use BEGIN 
# 2. path of libs
#	compiler directive (pragma)
# 3. use compiler option ; include
#	-I/tmp/training
use Ex; # compile time mechanism
$, = "\t"; $\ = "\n";
print "library path : ", @INC;
Ex::f();
