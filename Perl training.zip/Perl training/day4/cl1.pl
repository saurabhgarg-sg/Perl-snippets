#does not work
unshift @INC, "/tmp/training"; # runtime mechanism
use Ex; # compile time mechanism
$, = "\t"; $\ = "\n";
print "library path : ", @INC;
Ex::f();
