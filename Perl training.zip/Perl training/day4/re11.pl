# back reference or memory : not in classical regex
#	$1 $2 ...
#	in the same pattern, \1 \2 ...
# match a string where a char repeats
$_ = "hello";
if(/../)
{
	print "matched : $& \n";
}
if(/(.)\1/)
{
	print "memory : $1 \n";
	print "matched : $& \n";
}

$_ = "abcdefgh";
if(/((..)(..))(.(..).)/)
{
	print "\$1 $1\n";  # abcd
	print "\$2 $2\n";  # ab
	print "\$3 $3\n";  # cd
	print "\$4 $4\n";  # efgh
	print "\$5 $5\n";  # fg
	
}

$_ = "ababababcd";
if(/(.*)\1/)
{
	print "match : $& \n";
	print "first : $1 \n";
}

$_ = "abcd";
if(/(.*)\1/)
{
	print "match : $& \n";
	print "first : $1 \n";
}

$_ = "abcdcd";
if(/(.*)\1/)
{
	print "match : $& \n";
	print "first : $1 \n";
}

$_ = "abcdcd";
if(/(.*)\1$/)
{
	print "match : $& \n";
	print "first : $1 \n";
}










