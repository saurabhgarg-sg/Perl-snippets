# point in 2 dim
package P2D;
# @_ = (P2D, x, y)
sub new
{
	bless 	{ X => $_[1], Y => $_[2] }, $_[0];
}

sub disp
{
	print "X : ", $_[0]->{X}, "\n";
	print "Y : ", $_[0]->{Y}, "\n";

}
1;

