$_ =  "123abc";
/[\d\D]/; # matches a char
print $&, "\n"; # 1
/\d\D/; # two char ; digit followed by nondigit
print $&, "\n"; # 3a 

# match cat cot cut c+ c.t and not coat
# shell : match a char ?
# regex : match a char .
$_ = <STDIN>; chomp;
if(/c.t/)
{
	print "c.t success \n";
}
if(/c[.]t/)  # c.t     /c\.t/
{
	print "c[.]t success \n";
}
