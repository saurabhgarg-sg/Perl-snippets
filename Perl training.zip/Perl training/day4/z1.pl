# experiment with perlcc ; not for production
print "hello\n";
