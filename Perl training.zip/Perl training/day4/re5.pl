$_ = "axxxbyyybzzz";

# simulate * of shell 	.* in regex
/a.*b/;
print "match : $& \n";

# rules :
# 1. match from subject to pattern ; find the leftmost match
# 2. be eager
# 3. be greedy
#	backtracking is builtin

# non greedy match
/a.*?b/;
print "match : $& \n";

