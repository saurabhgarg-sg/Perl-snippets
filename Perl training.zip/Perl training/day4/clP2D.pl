use P2D;
$a = new P2D(3, 4);
$a->disp();
