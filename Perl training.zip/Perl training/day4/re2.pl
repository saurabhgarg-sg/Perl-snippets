# single char pattern
# /t/ 	t
# /\t/	tab  ; escaping - to give a special meaning
# /\//  /    ; escaping - to remove special meaning

# match lower case vowel 
# /aeiou/	matches a string containing aeiou in that order; all of them
# /a|e|i|o|u/	alternator : too powerful for choosing a char

$_ =  "heat";
/[aeiou]/;	# character class ; matches a char; a set
print "match :  $& \n";
# Rule 1:  match from subject to pattern ; find the leftmost match

# /[aaa]/	/a/  	char class is a set  /[a]/   /a/
# /aaa/		/aaa/

# digit of decimal number system
# /[0123456789]/
# range ?
# perl : range : ..
#	25 .. 79  numeric range
#	27 .. 59 
#	7 .. 5   # not an error ; empty range
# regex : range: -
#	[25-79] char range	[25679]
#	[27-59] 
$_ = <STDIN>;
if(/[0..9]/)    # 0|.|9
{
	print "success : $& \n";
};
if(/[0-9]/)    # 
{
	print "success : $& \n";
};
# /[27-59]/; # error

# letter :  /[A-z]/	extra 6 char
#	    /[A-Za-z]/
# hex digit /[0-9A-Fa-f]/

#	/[aeiou]/      a|e|i|o|u

# ^ as the first char of char class : inverts pattern matching
if(/[^aeiou]/) # match any thing other than a e i o u
{
	print "[^aeiou] success : $&\n";
}

# /[09-]/
# /[-09]/
# /[0\-9]/
# /[09\-]/
	# 0 or - or 9
# - is special only in the middle of char class


# /[aeiou^]/	a or e or i or o or u or ^
# /[^^]/	anything other than caret
# /[\^^]/	^

# /[0-9]/	\d
# /[^0-9]/	\D
# /[A-Za-z0-9_]/	\w
# /[^A-Za-z0-9_]/	\W
# /[ \t\n\r\f]/		\s
# /[^ \t\n\r\f]/	\S

# hex digit
# /[\dA-Fa-f]/











































