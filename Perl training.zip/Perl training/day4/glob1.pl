# six elements 
#	scalar
#	array
#	hash
#	function
#	file handle
#	format : output to a file using formats


$a = 10;
@a = (1, 2, 3, 4);
%a = (11, 22, 33, 44);
sub a {
	print "function\n";
}

*b = *a;
$, = "\t";
print $b, "\n";
print @b, "\n";
print %b, "\n";
b();

# how to pass open file handle as arg to a fn ?
open F, "glob1.pl" or die $1;
disp(*F);
close F;


sub disp
{
	*G = shift;
	print while(<G>);
	
}


# create a fn on the fly
*what =	sub { print "this is a new fn \n" ; };
	
what();





