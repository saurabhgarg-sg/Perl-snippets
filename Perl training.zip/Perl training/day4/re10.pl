$_ = "this is a test 5  in matching 6";
$count = 0;
$count1 = $count2 = 0;
while(/i|\d/)
{
	$_ = $';
	
	$count1++ if ($& =~ /i/);
	$count2++ if ($& =~ /\d/);

	$count++;
}	
print "# of occurences : $count \n";
print "# of occurences of i : $count1 \n";
print "# of occurences of digit : $count2 \n";

