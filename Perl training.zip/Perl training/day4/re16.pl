$_ = "/tmp/training/day4/re1.pl";
/.*\/(.*)/;
print $1, "\n";
m|.*/(.*)|;
print $1, "\n";
m?.*/(.*)?;
print $1, "\n";
m(.*/(.*)?) ;
print $1, "\n";
