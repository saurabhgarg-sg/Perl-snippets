$_ = "X%2BY%25Z";   # X + Y % Z

# 2B	0010 1011   => 43 dec  ASCII
#print hex("2B"), "\n";
#print chr(hex("2B")), "\n";
#print chr(hex("25")), "\n";

s/%(..)/chr(hex($1))/ge;
print $_, "\n";

