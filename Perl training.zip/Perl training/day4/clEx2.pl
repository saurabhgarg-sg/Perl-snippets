# use Ex2;
# by default, elements in array @EXPORT are imported
#use Ex2 ('$a', '$c');   # import specified symbols
#use Ex2 qw($a $c $e);

#use Ex2 qw(:SOME);
use Ex2 qw(:MORE);
print "a : $a  \n";
print "b : $b  \n";
print "c : $c  \n";
print "d : $d  \n";
print "e : $e  \n";
print "d : $d  \n";
print "g : $f  \n";
print "h : $h  \n";

print "a : $Ex2::a  \n";
print "b : $Ex2::b  \n";
print "c : $Ex2::c  \n";
print "d : $Ex2::d  \n";
print "e : $Ex2::e  \n";
print "d : $Ex2::d  \n";
print "g : $Ex2::f  \n";
print "h : $Ex2::h  \n";
