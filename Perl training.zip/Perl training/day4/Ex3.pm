package Ex3;
sub AUTOLOAD
{
	print "autoloader \n";
	print $AUTOLOAD, "\n";
	$AUTOLOAD  =~ s/.*:://;
	print $AUTOLOAD, "\n";
	*{$AUTOLOAD} = sub {
		print "new fn created \n";
	};
	goto &AUTULOAD;
}
1;

