$_ = "good food";
if(/o+/)
{
	print "success : $& \n"; # oo
}
if(/o*/) # successfully match nothing
{
	print "success : $& \n"; 
}
