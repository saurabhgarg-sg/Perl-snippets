use Event;
$e =  new Event(15, 8, 1947, "India became independent");
$e->disp();
