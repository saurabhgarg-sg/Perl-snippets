# change a string
# tr : trasliterator
# s  : substitute

$, = "\t"; $\ = "\n";

$_ = "food";
tr/f/g/;
print; # good

$_ = "food";
tr/of/en/;
print; #  need

$_ = "food";
tr/a-z/A-Z/;
print; #  NEED


$_ = "zebra";
tr/a-yz/b-za/;
print; # afcsb

$_ = "zebra";
tr/a-y/b-z/;
print; # zfcsb


$_ = "abcd";
tr/abcd/xy/;   # /xyyy/
print ;

$_= "A + B + C";
tr/+/ /;
print ;











 




















