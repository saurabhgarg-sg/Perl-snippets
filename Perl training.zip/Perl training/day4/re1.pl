# regular expressions
#	perldoc perlre
#	type 3 lang ; Chomsky's hierarchy lang
#	formal mechanism : finite state machine
#	
# perl :
#	=~    matching
#	!~    not matching

$, = "\t"; $\ = "\n";
$x = "together";
if($x =~ /get/)
{
	print "success \n";
	print "before the match : ", $`;
	print "matched ", $&;
	print "after the match : ", $';
}
$_ = "together";
if(/get/)   # $_ =~ /get/
{
	print "success \n";
	print "before the match : ", $`;
	print "matched ", $&;
	print "after the match : ", $';
}


# programs are run under some shell
# programs in perl
#  / /  => syntax of re













