# six elements 
#	scalar
#	array
#	hash
#	function
#	file handle
#	format : output to a file using formats

# output
#	print  : free format
#	printf : similar to 'C'
#	write  : using formats

# write followed by a file handle
write ; # write stdout

# default format name is same as the filename
# format ends with a . all by itself on a line
format STDOUT =
this is a test format
over
.

$a = "ant";
open F, ">junk" or die($!);
write F;
write F;
write F;
write F;

format F_TOP = 
this is the page header
.
format F =
this is format F
@<<<<
$a
@>>>>
$a
@||||
$a
.
close F;





