$_ = "100.80.60.40";
/(\d+)\.(\d+)\.(\d+)\.(\d+)/;
print $1, "\n";
print $2, "\n";
print $3, "\n";
print $4, "\n";

$, = "\t";
@a = /(\d+)\.(\d+)\.(\d+)\.(\d+)/;
print @a, "\n";
@a = /(\d+)/;
print @a, "\n";
@a = /(\d+)/g;
print @a, "\n";

$_ = "blue pen blue book blue sky";
@a = /blue (\w+)/g;
print @a, "\n";

$_ = "/tmp/training/day4/re12.pl";
/.*\/(.*)/;
print $1, "\n";

#...  unless(/^\s*$/);








