
package Complex;
use overload '+' => 'add'; # operator overloading
sub new
{
	my $class = shift;
	my $self = {
		RP => shift,
		IP => shift
	};
	bless $self, $class;
	return $self;
}

sub disp
{
	my $self = shift;
	print "Real Part : ", $self->{RP}, "\n";
	print "Imag Part : ", $self->{IP}, "\n";
}

sub add
{
	my ($lhs, $rhs) = @_;
#	my $self = {
#		RP => $lhs->{RP} + $rhs->{RP},
#		IP => $lhs->{IP} + $rhs->{IP}
#	};
#	bless $self, "Complex"; # hard coding
#	return $self;
	return Complex->new(
	 	$lhs->{RP} + $rhs->{RP},
		$lhs->{IP} + $rhs->{IP}
	);
}





1;



# books :
#	1. learning perl	: Oreilly
#	2. programming perl
#	3. perl cookbook
#	4. advanced Perl
#	5. mastering regular expressions

#	6. oo perl : Manning












