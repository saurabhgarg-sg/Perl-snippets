# 1729 -1729 +1729
chomp($_ = <STDIN>);
# ? following closure : nongreedy
# a char pattern : 0 or 1 optional
# \? matches a ?

if(/[+-]?\d+/ )
{
	print "success $&\n";
}

# /c?t/		ct   t   cat 
# optional c and then t
