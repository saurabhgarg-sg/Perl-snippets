# substitute
$, = "\t"; $\ = "\n";
$_ = "blue sky blue book blue pen";
s/blue/black/;
print;

$_ = "blue sky blue book blue pen";
s/blue/black/g;
print;

$_ = "this    is            a            test";
s/\s+/ /g;
print ;

$_ = "      this    is            a            test     ";
s/\s+/ /g;
s/^ //;
s/ $//;
print ;


