use Date;
$d1 = new Date(15, 8, 1947);
$d1->disp();
	
