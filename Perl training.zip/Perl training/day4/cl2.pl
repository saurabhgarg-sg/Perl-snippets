# change value of @INC at compile time
# 1. use BEGIN 
BEGIN  # executed at compile time; sub is optional
{
unshift @INC, "/tmp/training"; 
}
use Ex; # compile time mechanism
$, = "\t"; $\ = "\n";
print "library path : ", @INC;
Ex::f();
