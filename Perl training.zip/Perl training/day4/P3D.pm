package P3D;
use P2D;
@ISA = (P2D); # inheritance
# @_ = (P3D, x, y, z)
sub new
{
	my $class = shift;
	my $self = new P2D(shift, shift);
	$self->{Z} = shift;
	bless $self, $class;
	return $self;
}

sub disp
{
	my $self = shift;
	$self->P2D::disp();
	print "Z : ", $self->{Z}, "\n";
}
1;

