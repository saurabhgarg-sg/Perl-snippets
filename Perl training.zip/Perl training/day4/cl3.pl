# change value of @INC at compile time
# 1. use BEGIN 
# 2. path of libs
#	compiler directive (pragma)
use lib '/tmp/training'; # effect : add the path in the beginning
use Ex; # compile time mechanism
$, = "\t"; $\ = "\n";
print "library path : ", @INC;
Ex::f();
