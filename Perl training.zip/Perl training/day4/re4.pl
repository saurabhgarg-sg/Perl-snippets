# multiple char regex
# shell : * 0 or more char 
# regex : * closure 0 or more of what is before *
chomp ($_ = <STDIN>);
if(/ab*d/) # a then 0 or more b then d
{
	print "success 1 \n";
}

# +  positive closure
if(/ab+d/) # a then 1 or more b then d
{
	print "success 2 \n";
}


