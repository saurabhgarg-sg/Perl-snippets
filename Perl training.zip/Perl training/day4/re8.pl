# anchor
chomp ($_ = <STDIN>);
#if( /cat/ )
#{
#	print "success $& \n";
#}
#if( /^cat/ )
#{
#	print "success $& \n";
#}

# /^ anchor
# [^ ] invertor
# [ ^] literal

#if(/^[^^]/) # start with not a caret
#{
#	print "success $& \n";
#}

#if( /cat$/ )
#{
#	print "success $& \n";
#}

if( /^cat$/ )
{
	print "success $& \n";
}















