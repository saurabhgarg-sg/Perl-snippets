package Date;
sub new
{
	my $class = shift;
	my $self = {
		DD => shift,
		MM => shift,
		YY => shift
	};
	bless $self, $class;
	return $self;
}

sub disp
{
	my $self = shift;
	print "Date : ", $self->{DD}, " - ", $self->{MM}, " - ",
		$self->{YY}, "\n";
}
1;
