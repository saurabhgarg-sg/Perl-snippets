use P3D;
$a = new P3D(3, 4, 5);
$a->disp();
