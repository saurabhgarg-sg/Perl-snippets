# array
#	like a named list
#	has number of scalars
#	name starts with @
#	array name is not a pointer
#	stands for the whole array
$, = "\t"; $\ = "\n";
@a = (10, 20, 30, 40);

print @a;
# print 10. $, . 20 .  $,   ...
$a = 111; # ok
print @a;
print $a;
# index on the array : index by integer
#	lowerbound : 0 by default
print $a[2];# getting a single value
print $a[8]; # undef ; not an error accessing outside the bounds
$a[2] = 33;
print @a;
# array can grow or shrink
$a[6] = 66; # $a[4], $a[5] become undef
print @a;
$b[2] = 1111; # creates an array on the fly
print @b;
@a = (10, 20, 30, 40);
print $a[1,3];  # $a[3]
# $ => single value, , becomes an op
# secion / slice
print @a[1,3];  # ($a[1],$a[3])
# @ => multiple values, comma is sep
@a[1,3] = (111, 222);
print @a;
@a[1,3] = (111, 222, 333, 444);
print @a;
@a[1,3] = (1111);
print @a;
# index on a list 
@a[1,3] = (111, 222, 333, 444)[2,3];
print @a;
#print stat("x1.pl");
$size  = (stat('x1.pl'))[7];
print $size;


@a = (10, 20, 30, 40);
print @a[1 .. 3];  #  .. range   ($a[1], $a[2], $a[3])

@b = (1 .. 5);  # (1, 2, 3, 4, 5)
print @b;
@b = (5 .. 1); # ()
print @b;
@b = (1.5 .. 5.5); # (1 .. 5)
print @b;


































