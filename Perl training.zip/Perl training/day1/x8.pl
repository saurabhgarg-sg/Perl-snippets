# looping structures
# 1. while
#	while(<expr>)
#	{
#		<stat> ...
#	}
#	require a block if even there is a single stmt

$, = "\t"; $\ = "\n";
@a = (10, 20, 30, 40);
#i = 0; # bareword;  string     'i' = 0; no lvalue; error
$i = 0;
while($i < @a)
{
	print $a[$i];  # $a['i']	$a[0]
	$i++;
}
#  $i < $#a     # wrong
#  $i <= @a	# wrong
#  $i <= $#a    # ok
#  $i < @a      # ok

# @a == @b  compares the sizes

# 2. for(<expr>; <expr> ;<expr>)
#	{
#		<stat> ...
#	}

for($i = 0; $i < @a; ++$i)
{
	print $a[$i];
}

# 3. foreach <var> <list>
# 	{
#		<stmt> ...
#	}

foreach $x ("wall", "ritchie", "gosling")
{
	print $x;
}

foreach $x ( 1 .. 5)
{
	print $x;
}

# $x is a reference to each element in the list
foreach $x (@a)
{
	print $x;
	# can we modify loop control variable ?
	$x += 100;# modifies the element of the array
}
print @a;













