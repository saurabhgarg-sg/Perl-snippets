# assignment and arrays
# assignment compatible; elements are copied
$, = "\t"; $\ = "\n";
@a = (10, 20);
@b = @a;
$a[2] = 30; # does not affect @b
print @a;
print @b;

@a = (10, 20);
@b = (30, 40);
(@a, @b) = (@b, @a);
# (@a, @b) = ((30, 40), (10, 20))
# (@a, @b) = (30, 40, 10, 20)
# @a = (30, 40, 10, 20)# arrays are greedy
# @b = () # starved
print @a;
print @b;

@a = (10, 20, 30, 40);
# array => array
@b = @a;
# scalar => array
#	list containing a scalar to an array
@b =  111; # @b = (111);
print @b, "over";
# array to list containing a scalar
($x) = @a; # ($x) = (10, 20, 30, 40)
print $x;# 10
# array to a scalar
$x = @a;# use of array in scalar context ; size of the array
print $x; # 4
$x = (10, 20, 30, 40);
print $x; # 40


# context ;
#	array in list context : list
#	array in scalar context : size of the array




@a = (10, 20, 30, 40);
print @a . "\n"; # "4\n" # . works only on scalars
@a = @a + 5;
# @a = 4 + 5
# @a = 9
# @a = (9)
print @a;# 9


@a = (10, 20, 30, 40);
# @a += 5; # 4 += 5  ; @a in scalar context to the left assignment
#	not allowed as it would be a constant
print @a;

# last element of an array

print $a[@a - 1];
print "index of the last element : ", $#a;
print $a[$#a];
print $a[-1];

@a = (10, 20, 30, 40, 50, 60);
$i = 3;
$x = 35;
# insert $x in posn $i in the array @a
@a = (@a[0 .. $i - 1], $x, @a[$i .. $#a]);
print @a;











































