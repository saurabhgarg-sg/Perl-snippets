@a = <STDIN>;  # read until eof
# each line of input becomes an element of the array
print @a;

