@a = `ps`;
chomp @a;
$, = "\n";
#print @a;
#print scalar(@a);
foreach $i (1 .. $#a)
{
#	print $a[$i];
#	split  : converts a scalar to a list
#	print split(/ +/, $a[$i]);		
	$a[$i] =~ s/^ +//;
	($pid, $cmd) = ( split(/ +/, $a[$i]) )[0, -1];		
#	print $pid, $cmd;
	if($cmd eq "sleep")
	{
		print "killing sleep cmd \n";
		system("kill -9 $pid");
	}
}
