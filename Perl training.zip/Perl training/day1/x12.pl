$\ = "\n";
$, = "\t";
$a = "10,20,30,40";
# split : convert a scalar to a list
@x = split /,/, $a;
print @x;
# join : convert a list to a scalar
print join("zzz", @x);
