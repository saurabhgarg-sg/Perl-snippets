# input
# variable
#	types:
#	scalar
#		has a single value
#		stored as a string
#		no declaration of variable wrt type
#		first char of variable name : $
# assignment : similar to C++
# no difference in l-value and r-value usage of variable
$a = 10;
$b = $a;
print $a, "\n";
print $b, "\n";
# shell :
#	a=10   # no space on either side of assignment
#	b=$a   # difference in l-value or r-value usage

# no difference
$c = 10;
$d = "10";

# input from a file
# <filehandle> angled bracket
# files opened : stdin stdout stderr
# reads until a new line, by default
# even reads input record separator
# remove the input record sep ; chomp
# removes only if it is input record sep
# input record sep : $/

$x = <STDIN> ;
chomp $x;
chomp ($y = <STDIN>);
chomp $x; # does not do anything !
print $x, $y;





# functions
#	perldoc perlfunc
# variables 
#	perldoc perlvar







