# relational operators
# < <= > >= == !=  <=>   : numeric
# lt le gt ge eq ne cmp  :string

# <=>	3 way comparison operator
$, = "\t"; $\ = "\n";
print 5 <=> 5; # 0
print 5 <=> 2; # 1
print 5 <=> 10; # -1
# sorting technique : stable sort

# true : 5 -5 1 "novell" "00"
# false :0 ""	"0" undef
print 5 > 3; # 1
print 5 < 3; # undef

# rel op are not associative; syntax error
#print 5 == 5 == 5;

# logical operators
# ! && ||          similar to 'C'	higher prec
# not and or	   similar to Pascal    lower prec

print "cat" == "dog"; # 1
print "cattle" == "dog"; # 1

print "cat" eq "dog";  # undef

$x = <STDIN>; # cat
chomp $x;
print $x eq "cat"; # 1 with chomp; undef without chomp !!!

print 5 > 25; # undef; whole value is considered while comparing
print 5 gt 25; # 1 ; compare corresponding chars until a mismatch
print 05 gt 25; # 1 ; compare corresponding chars until a mismatch


$a = 0;
$b = 10;
# short ckt eval
print $a == 0 or $b / $a > 5;  # 1











































