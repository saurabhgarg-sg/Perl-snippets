# use strict;  # should always be used in production
# course : Perl & Python
# N S Kumar
# kumaradhara@gmail.com
# Perl : Practical Extraction & Report Language
#	designed by Larry Wall
#	as an improvement on awk
#	version : 5.8.x
#	perl6 is being designed by a committee
#	
#	activestate.com
#	cpan.org
#		comprehensive perl archive network


# features :
#	use perl in web based appln
#		most probably modperl with apache
#	powerful in string manipulation
#		regular expression : type 3 lang : Chomsky
#	scripting lang :
#		no strong type; weakly typed lang
#		stored as strings	
#		based on context, value is chosen
#	compiled, then interpreted
#	executes some code during compilation
#	does not generate a binary
#	compiles to a tree structure
#	free ; distribution in source
#	context sensitive
#	data types
#		scalar : single value
#		array  : number of scalars; indexed by integer
#		hash   : key value pairs ; indexed by string
#		reference : like pointer of 'C'
#	time for development short
#	programs tend to be small
#	may not be as efficient as 'C' or C++
#	data structures 
#		work around - require reference
#	control structure
#		too powerful
#	modular development : functions
#	file handling :
#		read, write, append, i/o
#		open output of a command as a file
#		send input to a command thro the pgm (popen in 'c')
#		powerful
#	Object Oriented
#       CONTEXT SENSITIVE
# 
# run the program
# 1. perl <filename>

# structure :
#	case sensitive
#	no entry fn
#	free format source code (?)
#	consists of number of statements
#	a statement ends in a ; ( statement terminator)
#	statement can span over number of lines
#	more than one statement on the same line

# print :
#	free format output operation
#	is a fn call
#	can take any number of arguments
#	escape sequences as in 'C'
#	parentheses are optional

print "hello world\n";
#Print "hello world\n"; # error
print
	"hello world\n";
print "hello", "world\n";
print ("hello", "world\n");
# can also number crunching
#print 2 + 2;   # 4
#print (2 + 2);
#print (2 + 2) * 5;  # 4
#
print(print (2 + 2) * 5); #45
3 + 4; # perfectly ok !
# an expr followed by a semicolon is a stmt !

# parentheses bind with the fn name strongly
#print hello ; # file op has failed !
print stdout hello;
# bareword ; no prefix

print "over\n";



		











































