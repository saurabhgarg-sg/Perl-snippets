# operators
chomp ($x  = <STDIN>);
chomp ($y  = <STDIN>);
print $x + $y, "\n";
print $x . $y, "\n";

print 25 / 4, "\t", 25 % 4, "\t", 25.6 % 4.2, "\n";
#     6.25          1		  1
# arithmetic
#	+ - * / %
# string
#	.	concatenation
#	x	replication
#		left : string; right : integer
print "cat" x 3, "\t", 25 x 3 , "\t", "perl" x 2.5,  "\n";
#	catcatcat	252525
# context :
#	scalar
#	1. string
#	2. numeric
#	3. numeric integer]]

# assignment
$a = 10; $b = 20;
$a = $b = 30; # multiple assignment
print $a, "\t", $b, "\n" ;
# if the result of an operation is stored in a variable
#	of the programmer, it is a l-value
# otherwise it is a r-value
($a = 40) = 50; # ok
print $a, "\n";

# combined assignment and arithmetic/string op
# += -= *= /= %= .= x=   ; have low precedence
$b = 10;
$b *= 2 + 2; # $b = $b * (2 + 2);
print $b, "\n"; # 40

$b = 10;
($b *= 2) += 2;
print $b, "\n"; # 22 

# incr/decr a var by 1
# ++ --
#	unary, pre/post
$a = "cat";
$a = $a + 1;
print $a, "\n";# 1

$a = "cat";
$a++; # auto incr can be magical
print $a, "\n";# cau

$a = "zz";
$a++; # auto incr can be magical
print $a, "\n";# cau

$a = "zz";
$a--; # auto decr is not magical
print $a, "\n"; # -1

# perldoc perlop

# relop, logical op, if expr ...



















