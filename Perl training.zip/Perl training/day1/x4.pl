# list
#	has number of scalars enclosed in parentheses
#	has no name
#	no list of lists
#	examples
#		(10, 20)
#		(10, "ten", 3.14)
#		(3 + 4, "ten" . "twenty") # list of expr
#		($a, $b) # list of scalar variables
#		(10, (20, 30), 40) becomes
#			(10, 20, 30, 40)
#	
#	list assignment
# $, : output field sep
# $\ : output record sep

$, = "\t"; $\ = "\n";
($a, $b) = (10, 20);
print $a, $b;  # 10 20
($a, $b) = (30, 40, 50); # extra values on the right are discarded
print $a, $b;  # 30 40
($a, $b) = (60); # $b becomes "undef"
# undef : string => ""
#	  numeric => 0
print $a, $b;  # 60

# rules of assignment
# 1. evaluate rhs in the context of lhs
# 2. evaluate rhs completely before assignment

($a, $b) = (10, 20);
# swap
($a, $b) = ($b, $a);
# ($a, $b) =(20, 10)
print $a, $b;  # 20 10

# assignment of list to list containing a scalar
($x) = (10, 20, 30);
print $x; # 10
# assignment of list to a scalar
# comma op:
#	least prec of all operators
#	sequencing operator
#	works left to right
#	value : value of the rightmost

# rhs should become a scalar
# , becomes an op
# value : value of the rightmost : 30
$x = (10, 20, 30);
print $x; # 30


# context
# list in list context : list
# list in scalar context : rightmost element
# list assignment in list context : list
# list assignment in scalar context : # of elements on rhs of list
#		assignment

# scalar to a list
# equivalent to assignment of a list containing a scalar to a list

($a, $b) = 40;
# ($a, $b) = (40)
print $a, $b ; # 40 
# assignment of list assignment to a list
($a) = ($x, $y) = (11, 22, 33, 44);
print $a; # 11
# assignment of list assignment to a scalar 
# number of elements on the rhs of list assignment
$a = ($x, $y) = (11, 22, 33, 44);
print $a; # 4
$a = (11, 22, 33, 44);
print $a; # 44






























