# walk thru the directory
@a = `ls`;
chomp @a;
#print @a;
foreach $name (@a)
{
#	print $name;
	#$name = chomp $name; # chomp does not return the string
	#chomp $name; # ok
	if( -f $name)
	{
		print "$name : file\n";
	}
	elsif( -d $name)
	{
		print "$name : dir\n";
	}
	else
	{
		print "$name : unknown \n";
	}

}
