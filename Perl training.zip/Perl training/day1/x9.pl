# quotes
$\ = "\n";
$a = "key";

print " $a "; # variable is substituted within double quotes
print ' $a '; # $a
print " $aword " ;# undef
print " ${a}word ";# keyword

@a = `ls`;
print "status : $? ";
print @a; # executes a command of the OS
@b = `ls junk`;

print "status : $? ";
$v = $? >> 8;
print "exit value : $v";

# executing commands of the OS
# `cmd`   	=> get the output
# system("cmd"); => get the status
# exec("cmd");	=> cmd replaces the present program
# pipe open modes




